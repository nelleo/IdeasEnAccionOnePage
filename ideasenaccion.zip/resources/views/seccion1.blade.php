<section class="d-flex flex-wrap w-100 marino flex-lg-row oh">
    <div class="col-lg-6 p-0">
        <div class="d-flex flex-column flex-lg-row w-100 tlb w1">
            <p class="p-5 ml-5 w1" style="color: aliceblue;font-size:large;">
                La convocatoria abierta del <strong> Premio Ideas en Acción </strong>invita a presentar  <strong>innovaciones implementadas</strong>  porempresas prestadoras de servicios de agua y/o saneamiento en América Latina y el Caribe.
                <br>Este año, la convocatoria también invita a las empresas a presentar<strong> desafíos </strong>que puedan ser atendidos a través de soluciones innovadoras en tecnologías inteligentes, desalinización, reúso y/o gestión.
                <br>En el 2020 el <strong>Premio Ideas en Acción </strong>consta de dos categorías.
            </p>
        </div>
        <div>
            <img class="" src="images/img--06.jpg" alt="fin bajada">
        </div>
    </div>
    <div class="col-lg-6 w1">
        <img class="fl" src="images/img--07.jpg" alt="ilus bajada">
    </div>
        
</section>
