<section class="text-center sp row d-flex w1" style="background-color:#044363;justity-content:center;margin:0%; ">
    <div class=" offset-1 col-md-2 mt-4">
        <img class="w1" src="images/img--23.jpg" alt="">
    </div>
    <div class="offset- col-md-6 mt-5">
        <h1 class="" style="text-decoration: underline;line-height: 1.2em;color:#04b3bb;font-weight: 650;letter-spacing:0.01em">Podrás ganar:</h1>
        <p class="w1 mt-4" style="color: #04b3bb;font-size: x-large;
            font-weight: 650;"><strong> Implementación de AquaRating +<br>
            y actividades de formación, promoción,<br>
           visibilidad y difusión.</strong></p>
    </div>
</section>