<section class="text-center sp d-flex flex-column justify-content-center mx-0 oh" style="background-color:#034360">
    <img class="" src="images/img--22.jpg" alt="intro seccion" style="width: 48px!important;position: relative;top: -9px;margin:auto;">
    <div class="d-flex justify-content-center">
        <div class="col-md-2 mt-4 d-none d-md-flex flex-wrap flex-column justify-content-end" style="transform: translate(-40px, 0px);">
            <img class="" src="images/img--23.jpg" alt="chica">
        </div>
        <div class="col-md-6 mt-5 mx-2">
            <h1 class="" style=";line-height: 1.2em;color:#04b3bb;font-weight: 650;letter-spacing:0.01em">
                @lang('menssages.poga')
            </h1>
            <div style="height: 4px;width: 270px;background-color:#04b3bb;display:inline-block;border-radius: 3px;position: relative;top: -5px;"></div>
            <p class="w1 mt-4 px-4 pb-5" style="color: #04b3bb;font-size: x-large;font-weight: 650;">
                @lang('menssages.p6')
            </p>
        </div>
        <div class="col-md-2 mt-4 d-none d-md-block">
            <img class="" src="images/img--23.jpg" alt="chica" style="opacity: 0;position: relative;right: 0;">
        </div>
    </div>
</section>