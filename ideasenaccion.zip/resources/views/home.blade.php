@extends("layout.base")
@section('main')
    @include('seccion1')
    @include('seccion2')
    @include('seccion3')
    @include('seccion4')
    @include('seccion5-3')
    @include('seccion6-4')
    @include('seccion7')
    @include('seccion8')
@endsection




