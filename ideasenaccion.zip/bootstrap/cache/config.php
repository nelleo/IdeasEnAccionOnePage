<?php return array (
  'app' => 
  array (
    'name' => 'IdeasEnAccion',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'asset_url' => NULL,
    'timezone' => 'America/Argentina/Buenos_Aires',
    'locale' => 'en',
    'fallback_locale' => 'es',
    'faker_locale' => 'es',
    'key' => 'base64:QLNKXucUZ2kKOa1W0F3z96rZn6Oucj4+BIygGlj1oQg=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Torann\\GeoIP\\GeoIPServiceProvider',
      1 => 'Illuminate\\Auth\\AuthServiceProvider',
      2 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      3 => 'Illuminate\\Bus\\BusServiceProvider',
      4 => 'Illuminate\\Cache\\CacheServiceProvider',
      5 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      6 => 'Illuminate\\Cookie\\CookieServiceProvider',
      7 => 'Illuminate\\Database\\DatabaseServiceProvider',
      8 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      9 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      10 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      11 => 'Illuminate\\Hashing\\HashServiceProvider',
      12 => 'Illuminate\\Mail\\MailServiceProvider',
      13 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      14 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      15 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      16 => 'Illuminate\\Queue\\QueueServiceProvider',
      17 => 'Illuminate\\Redis\\RedisServiceProvider',
      18 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      19 => 'Illuminate\\Session\\SessionServiceProvider',
      20 => 'Illuminate\\Translation\\TranslationServiceProvider',
      21 => 'Illuminate\\Validation\\ValidationServiceProvider',
      22 => 'Illuminate\\View\\ViewServiceProvider',
      23 => 'App\\Providers\\AppServiceProvider',
      24 => 'App\\Providers\\AuthServiceProvider',
      25 => 'App\\Providers\\EventServiceProvider',
      26 => 'App\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
      'GeoIP' => 'Torann\\GeoIP\\Facades\\GeoIP',
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
        'hash' => false,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'useTLS' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'array',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
    ),
    'prefix' => 'ideasenaccion_cache',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'ideasenaccion',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'ideasenaccion',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'ideasenaccion',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'ideasenaccion',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'ideasenaccion_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
      ),
    ),
    'links' => 
    array (
      'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\public\\storage' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\app/public',
    ),
  ),
  'geoip' => 
  array (
    'log_failures' => true,
    'include_currency' => true,
    'service' => 'ipapi',
    'services' => 
    array (
      'maxmind_database' => 
      array (
        'class' => 'Torann\\GeoIP\\Services\\MaxMindDatabase',
        'database_path' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\app/geoip.mmdb',
        'update_url' => 'https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-City&license_key=&suffix=tar.gz',
        'locales' => 
        array (
          0 => 'en',
        ),
      ),
      'maxmind_api' => 
      array (
        'class' => 'Torann\\GeoIP\\Services\\MaxMindWebService',
        'user_id' => NULL,
        'license_key' => NULL,
        'locales' => 
        array (
          0 => 'en',
        ),
      ),
      'ipapi' => 
      array (
        'class' => 'Torann\\GeoIP\\Services\\IPApi',
        'secure' => true,
        'key' => NULL,
        'continent_path' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\app/continents.json',
        'lang' => 'en',
      ),
      'ipgeolocation' => 
      array (
        'class' => 'Torann\\GeoIP\\Services\\IPGeoLocation',
        'secure' => true,
        'key' => NULL,
        'continent_path' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\app/continents.json',
        'lang' => 'en',
      ),
      'ipdata' => 
      array (
        'class' => 'Torann\\GeoIP\\Services\\IPData',
        'key' => NULL,
        'secure' => true,
      ),
      'ipfinder' => 
      array (
        'class' => 'Torann\\GeoIP\\Services\\IPFinder',
        'key' => NULL,
        'secure' => true,
        'locales' => 
        array (
          0 => 'en',
        ),
      ),
    ),
    'cache' => 'all',
    'cache_tags' => 
    array (
      0 => 'torann-geoip-location',
    ),
    'cache_expires' => 30,
    'default_location' => 
    array (
      'ip' => '127.0.0.0',
      'iso_code' => 'US',
      'country' => 'United States',
      'city' => 'New Haven',
      'state' => 'CT',
      'state_name' => 'Connecticut',
      'postal_code' => '06510',
      'lat' => 41.31,
      'lon' => -72.92,
      'timezone' => 'America/New_York',
      'continent' => 'NA',
      'default' => true,
      'currency' => 'USD',
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'locale' => 
  array (
    'status' => true,
    'languages' => 
    array (
      'es' => 
      array (
        0 => 'es',
        1 => 'es_ES',
        2 => false,
      ),
      'en' => 
      array (
        0 => 'en',
        1 => 'en_US',
        2 => false,
      ),
    ),
  ),
  'localization' => 
  array (
    'supported-locales' => 
    array (
      0 => 'en',
      1 => 'es',
    ),
    'accept-language-header' => true,
    'hide-default-in-url' => true,
    'redirection-code' => 302,
    'utf-8-suffix' => '.UTF-8',
    'route' => 
    array (
      'middleware' => 
      array (
        'localization-session-redirect' => true,
        'localization-cookie-redirect' => false,
        'localization-redirect' => true,
        'localized-routes' => true,
        'translation-redirect' => true,
      ),
    ),
    'ignored-redirection' => 
    array (
    ),
    'locales' => 
    array (
      'aa' => 
      array (
        'name' => 'Afar',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Qafar',
        'regional' => 'aa_ER',
      ),
      'ab' => 
      array (
        'name' => 'Abkhazian',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Аҧсуа',
        'regional' => '',
      ),
      'ace' => 
      array (
        'name' => 'Achinese',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Aceh',
        'regional' => '',
      ),
      'ady' => 
      array (
        'name' => 'Adyghe',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Адыгэбзэ',
        'regional' => '',
      ),
      'ae' => 
      array (
        'name' => 'Avestan',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Avesta',
        'regional' => '',
      ),
      'af' => 
      array (
        'name' => 'Afrikaans',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Afrikaans',
        'regional' => 'af_ZA',
      ),
      'agq' => 
      array (
        'name' => 'Aghem',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Aghem',
        'regional' => '',
      ),
      'ak' => 
      array (
        'name' => 'Akan',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Akan',
        'regional' => 'ak_GH',
      ),
      'ale' => 
      array (
        'name' => 'Aleut',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Unangax tunuu',
        'regional' => '',
      ),
      'am' => 
      array (
        'name' => 'Amharic',
        'script' => 'Ethi',
        'dir' => 'ltr',
        'native' => 'አማርኛ',
        'regional' => 'am_ET',
      ),
      'an' => 
      array (
        'name' => 'Aragonese',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Aragonés',
        'regional' => 'an_ES',
      ),
      'ang' => 
      array (
        'name' => 'Old English',
        'script' => 'Runr',
        'dir' => 'ltr',
        'native' => 'Old English',
        'regional' => '',
      ),
      'ar' => 
      array (
        'name' => 'Arabic',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'العربية',
        'regional' => 'ar_AE',
      ),
      'as' => 
      array (
        'name' => 'Assamese',
        'script' => 'Beng',
        'dir' => 'ltr',
        'native' => 'অসমীয়া',
        'regional' => 'as_IN',
      ),
      'asa' => 
      array (
        'name' => 'Kipare',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kipare',
        'regional' => '',
      ),
      'av' => 
      array (
        'name' => 'Avaric',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Авар мацӀ',
        'regional' => '',
      ),
      'ay' => 
      array (
        'name' => 'Aymara',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Aymar aru',
        'regional' => 'ay_PE',
      ),
      'az' => 
      array (
        'name' => 'Azerbaijani (Latin)',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Azərbaycanca',
        'regional' => 'az_AZ',
      ),
      'az-Cyrl' => 
      array (
        'name' => 'Azerbaijani (Cyrillic)',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Азәрбајҹан',
        'regional' => 'uz_UZ',
      ),
      'ba' => 
      array (
        'name' => 'Bashkir',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Башҡорт теле',
        'regional' => '',
      ),
      'bas' => 
      array (
        'name' => 'Basa',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ɓàsàa',
        'regional' => '',
      ),
      'be' => 
      array (
        'name' => 'Belarusian',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Беларуская',
        'regional' => 'be_BY',
      ),
      'bem' => 
      array (
        'name' => 'Bemba',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ichibemba',
        'regional' => 'bem_ZM',
      ),
      'bez' => 
      array (
        'name' => 'Bena',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Hibena',
        'regional' => '',
      ),
      'bg' => 
      array (
        'name' => 'Bulgarian',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Български',
        'regional' => 'bg_BG',
      ),
      'bh' => 
      array (
        'name' => 'Bihari',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Bihari',
        'regional' => '',
      ),
      'bi' => 
      array (
        'name' => 'Bislama',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Bislama',
        'regional' => '',
      ),
      'bm' => 
      array (
        'name' => 'Bambara',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Bamanakan',
        'regional' => '',
      ),
      'bn' => 
      array (
        'name' => 'Bengali',
        'script' => 'Beng',
        'dir' => 'ltr',
        'native' => 'বাংলা',
        'regional' => 'bn_BD',
      ),
      'bo' => 
      array (
        'name' => 'Tibetan',
        'script' => 'Tibt',
        'dir' => 'ltr',
        'native' => 'པོད་སྐད་',
        'regional' => 'bo_IN',
      ),
      'br' => 
      array (
        'name' => 'Breton',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Brezhoneg',
        'regional' => 'br_FR',
      ),
      'bra' => 
      array (
        'name' => 'Braj',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'ब्रज भाषा',
        'regional' => '',
      ),
      'brx' => 
      array (
        'name' => 'Bodo',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'बड़ो',
        'regional' => 'brx_IN',
      ),
      'bs' => 
      array (
        'name' => 'Bosnian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Bosanski',
        'regional' => 'bs_BA',
      ),
      'byn' => 
      array (
        'name' => 'Blin',
        'script' => 'Ethi',
        'dir' => 'ltr',
        'native' => 'ብሊን',
        'regional' => 'byn_ER',
      ),
      'ca' => 
      array (
        'name' => 'Catalan',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Català',
        'regional' => 'ca_ES',
      ),
      'ca-valencia' => 
      array (
        'name' => 'Valencian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Valencià',
        'regional' => '',
      ),
      'cch' => 
      array (
        'name' => 'Atsam',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Atsam',
        'regional' => '',
      ),
      'ce' => 
      array (
        'name' => 'Chechen',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Нохчийн мотт',
        'regional' => 'ce_RU',
      ),
      'cgg' => 
      array (
        'name' => 'Chiga',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Rukiga',
        'regional' => '',
      ),
      'ch' => 
      array (
        'name' => 'Chamorro',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Chamoru',
        'regional' => '',
      ),
      'chr' => 
      array (
        'name' => 'Cherokee',
        'script' => 'Cher',
        'dir' => 'ltr',
        'native' => 'ᏣᎳᎩ',
        'regional' => '',
      ),
      'co' => 
      array (
        'name' => 'Corsican',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Corsu',
        'regional' => '',
      ),
      'cr' => 
      array (
        'name' => 'Cree',
        'script' => 'Cans',
        'dir' => 'ltr',
        'native' => 'ᓀᐦᐃᔭᐍᐏᐣ',
        'regional' => '',
      ),
      'cs' => 
      array (
        'name' => 'Czech',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Čeština',
        'regional' => 'cs_CZ',
      ),
      'cu' => 
      array (
        'name' => 'Church Slavic',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Ѩзыкъ словѣньскъ',
        'regional' => '',
      ),
      'cv' => 
      array (
        'name' => 'Chuvash',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Чӑваш чӗлхи',
        'regional' => 'cv_RU',
      ),
      'cy' => 
      array (
        'name' => 'Welsh',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Cymraeg',
        'regional' => 'cy_GB',
      ),
      'da' => 
      array (
        'name' => 'Danish',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Dansk',
        'regional' => 'da_DK',
      ),
      'dav' => 
      array (
        'name' => 'Dawida',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kitaita',
        'regional' => '',
      ),
      'de' => 
      array (
        'name' => 'German',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Deutsch',
        'regional' => 'de_DE',
      ),
      'de-AT' => 
      array (
        'name' => 'Austrian German',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Österreichisches Deutsch',
        'regional' => 'de_AT',
      ),
      'de-CH' => 
      array (
        'name' => 'Swiss High German',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Schweizer Hochdeutsch',
        'regional' => 'de_CH',
      ),
      'dje' => 
      array (
        'name' => 'Zarma',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Zarmaciine',
        'regional' => '',
      ),
      'doi' => 
      array (
        'name' => 'Dogri',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'डोगरी',
        'regional' => 'doi_IN',
      ),
      'dua' => 
      array (
        'name' => 'Duala',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Duálá',
        'regional' => '',
      ),
      'dv' => 
      array (
        'name' => 'Divehi',
        'script' => 'Thaa',
        'dir' => 'rtl',
        'native' => 'ދިވެހިބަސް',
        'regional' => 'dv_MV',
      ),
      'dyo' => 
      array (
        'name' => 'Jola-Fonyi',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Joola',
        'regional' => '',
      ),
      'dz' => 
      array (
        'name' => 'Dzongkha',
        'script' => 'Tibt',
        'dir' => 'ltr',
        'native' => 'རྫོང་ཁ',
        'regional' => 'dz_BT',
      ),
      'ebu' => 
      array (
        'name' => 'Kiembu',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kĩembu',
        'regional' => '',
      ),
      'ee' => 
      array (
        'name' => 'Ewe',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Eʋegbe',
        'regional' => '',
      ),
      'en' => 
      array (
        'name' => 'English',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'English',
        'regional' => 'en_GB',
      ),
      'en-AU' => 
      array (
        'name' => 'Australian English',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Australian English',
        'regional' => 'en_AU',
      ),
      'en-GB' => 
      array (
        'name' => 'British English',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'British English',
        'regional' => 'en_GB',
      ),
      'en-US' => 
      array (
        'name' => 'U.S. English',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'U.S. English',
        'regional' => 'en_US',
      ),
      'el' => 
      array (
        'name' => 'Greek',
        'script' => 'Grek',
        'dir' => 'ltr',
        'native' => 'Ελληνικά',
        'regional' => 'el_GR',
      ),
      'eo' => 
      array (
        'name' => 'Esperanto',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Esperanto',
        'regional' => '',
      ),
      'es' => 
      array (
        'name' => 'Spanish',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Español',
        'regional' => 'es_ES',
      ),
      'et' => 
      array (
        'name' => 'Estonian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Eesti',
        'regional' => 'et_EE',
      ),
      'eu' => 
      array (
        'name' => 'Basque',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Euskara',
        'regional' => 'eu_ES',
      ),
      'ewo' => 
      array (
        'name' => 'Ewondo',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ewondo',
        'regional' => '',
      ),
      'fa' => 
      array (
        'name' => 'Persian',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'فارسی',
        'regional' => 'fa_IR',
      ),
      'ff' => 
      array (
        'name' => 'Fulah',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Pulaar',
        'regional' => 'ff_SN',
      ),
      'fi' => 
      array (
        'name' => 'Finnish',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Suomi',
        'regional' => 'fi_FI',
      ),
      'fil' => 
      array (
        'name' => 'Filipino',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Filipino',
        'regional' => 'fil_PH',
      ),
      'fj' => 
      array (
        'name' => 'Fijian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Vosa Vakaviti',
        'regional' => '',
      ),
      'fo' => 
      array (
        'name' => 'Faroese',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Føroyskt',
        'regional' => 'fo_FO',
      ),
      'fr' => 
      array (
        'name' => 'French',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Français',
        'regional' => 'fr_FR',
      ),
      'fr-CA' => 
      array (
        'name' => 'Canadian French',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Français canadien',
        'regional' => 'fr_CA',
      ),
      'fur' => 
      array (
        'name' => 'Friulian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Furlan',
        'regional' => 'fur_IT',
      ),
      'fy' => 
      array (
        'name' => 'Western Frisian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Frysk',
        'regional' => 'fy_DE',
      ),
      'ga' => 
      array (
        'name' => 'Irish',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Gaeilge',
        'regional' => 'ga_IE',
      ),
      'gaa' => 
      array (
        'name' => 'Ga',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ga',
        'regional' => '',
      ),
      'gd' => 
      array (
        'name' => 'Scottish Gaelic',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Gàidhlig',
        'regional' => 'gd_GB',
      ),
      'gl' => 
      array (
        'name' => 'Galician',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Galego',
        'regional' => 'gl_ES',
      ),
      'gn' => 
      array (
        'name' => 'Guaraní',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Avañe’ẽ',
        'regional' => '',
      ),
      'gsw' => 
      array (
        'name' => 'Swiss German',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Schwiizertüütsch',
        'regional' => '',
      ),
      'gu' => 
      array (
        'name' => 'Gujarati',
        'script' => 'Gujr',
        'dir' => 'ltr',
        'native' => 'ગુજરાતી',
        'regional' => 'gu_IN',
      ),
      'guz' => 
      array (
        'name' => 'Ekegusii',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ekegusii',
        'regional' => '',
      ),
      'gv' => 
      array (
        'name' => 'Manx',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Gaelg',
        'regional' => 'gv_GB',
      ),
      'ha' => 
      array (
        'name' => 'Hausa',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Hausa',
        'regional' => 'ha_NG',
      ),
      'haw' => 
      array (
        'name' => 'Hawaiian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'ʻŌlelo Hawaiʻi',
        'regional' => '',
      ),
      'he' => 
      array (
        'name' => 'Hebrew',
        'script' => 'Hebr',
        'dir' => 'rtl',
        'native' => 'עברית',
        'regional' => 'he_IL',
      ),
      'hi' => 
      array (
        'name' => 'Hindi',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'हिन्दी',
        'regional' => 'hi_IN',
      ),
      'ho' => 
      array (
        'name' => 'Hiri Motu',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Hiri Motu',
        'regional' => '',
      ),
      'hr' => 
      array (
        'name' => 'Croatian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Hrvatski',
        'regional' => 'hr_HR',
      ),
      'ht' => 
      array (
        'name' => 'Haitian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kreyòl ayisyen',
        'regional' => 'ht_HT',
      ),
      'hu' => 
      array (
        'name' => 'Hungarian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Magyar',
        'regional' => 'hu_HU',
      ),
      'hy' => 
      array (
        'name' => 'Armenian',
        'script' => 'Armn',
        'dir' => 'ltr',
        'native' => 'Հայերէն',
        'regional' => 'hy_AM',
      ),
      'hz' => 
      array (
        'name' => 'Herero',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Otjiherero',
        'regional' => '',
      ),
      'ia' => 
      array (
        'name' => 'Interlingua',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Interlingua',
        'regional' => 'ia_FR',
      ),
      'id' => 
      array (
        'name' => 'Indonesian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Bahasa Indonesia',
        'regional' => 'id_ID',
      ),
      'ig' => 
      array (
        'name' => 'Igbo',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Igbo',
        'regional' => 'ig_NG',
      ),
      'ii' => 
      array (
        'name' => 'Sichuan Yi',
        'script' => 'Yiii',
        'dir' => 'ltr',
        'native' => 'ꆈꌠꉙ',
        'regional' => '',
      ),
      'ik' => 
      array (
        'name' => 'Inupiaq',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Iñupiaq',
        'regional' => 'ik_CA',
      ),
      'io' => 
      array (
        'name' => 'Ido',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ido',
        'regional' => '',
      ),
      'is' => 
      array (
        'name' => 'Icelandic',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Íslenska',
        'regional' => 'is_IS',
      ),
      'it' => 
      array (
        'name' => 'Italian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Italiano',
        'regional' => 'it_IT',
      ),
      'iu' => 
      array (
        'name' => 'Inuktitut (Canadian Aboriginal Syllabics)',
        'script' => 'Cans',
        'dir' => 'ltr',
        'native' => 'ᐃᓄᒃᑎᑐᑦ',
        'regional' => 'iu_CA',
      ),
      'iu-Latin' => 
      array (
        'name' => 'Inuktitut (Latin)',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Inuktitut',
        'regional' => 'ia_FR',
      ),
      'ja' => 
      array (
        'name' => 'Japanese',
        'script' => 'Jpan',
        'dir' => 'ltr',
        'native' => '日本語',
        'regional' => 'ja_JP',
      ),
      'jmc' => 
      array (
        'name' => 'Machame',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kimachame',
        'regional' => '',
      ),
      'jv' => 
      array (
        'name' => 'Javanese (Latin)',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Basa Jawa',
        'regional' => '',
      ),
      'jv-Java' => 
      array (
        'name' => 'Javanese (Javanese)',
        'script' => 'Java',
        'dir' => 'ltr',
        'native' => 'ꦧꦱꦗꦮ',
        'regional' => '',
      ),
      'ka' => 
      array (
        'name' => 'Georgian',
        'script' => 'Geor',
        'dir' => 'ltr',
        'native' => 'ქართული',
        'regional' => 'ka_GE',
      ),
      'kab' => 
      array (
        'name' => 'Kabyle',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Taqbaylit',
        'regional' => 'kab_DZ',
      ),
      'kaj' => 
      array (
        'name' => 'Jju',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kaje',
        'regional' => '',
      ),
      'kam' => 
      array (
        'name' => 'Kamba',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kikamba',
        'regional' => '',
      ),
      'kcg' => 
      array (
        'name' => 'Tyap',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Katab',
        'regional' => '',
      ),
      'kde' => 
      array (
        'name' => 'Makonde',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Chimakonde',
        'regional' => '',
      ),
      'kea' => 
      array (
        'name' => 'Kabuverdianu',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kabuverdianu',
        'regional' => '',
      ),
      'kg' => 
      array (
        'name' => 'Kongo',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kikongo',
        'regional' => '',
      ),
      'khq' => 
      array (
        'name' => 'Koyra Chiini',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Koyra ciini',
        'regional' => '',
      ),
      'ki' => 
      array (
        'name' => 'Kikuyu',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Gikuyu',
        'regional' => '',
      ),
      'kj' => 
      array (
        'name' => 'Kuanyama',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kwanyama',
        'regional' => '',
      ),
      'kk' => 
      array (
        'name' => 'Kazakh',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Қазақ тілі',
        'regional' => 'kk_KZ',
      ),
      'kl' => 
      array (
        'name' => 'Kalaallisut',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kalaallisut',
        'regional' => 'kl_GL',
      ),
      'kln' => 
      array (
        'name' => 'Kalenjin',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kalenjin',
        'regional' => '',
      ),
      'km' => 
      array (
        'name' => 'Khmer',
        'script' => 'Khmr',
        'dir' => 'ltr',
        'native' => 'ភាសាខ្មែរ',
        'regional' => 'km_KH',
      ),
      'kn' => 
      array (
        'name' => 'Kannada',
        'script' => 'Knda',
        'dir' => 'ltr',
        'native' => 'ಕನ್ನಡ',
        'regional' => 'kn_IN',
      ),
      'ko' => 
      array (
        'name' => 'Korean',
        'script' => 'Hang',
        'dir' => 'ltr',
        'native' => '한국어',
        'regional' => 'ko_KR',
      ),
      'kok' => 
      array (
        'name' => 'Konkani',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'कोंकणी',
        'regional' => 'kok_IN',
      ),
      'kr' => 
      array (
        'name' => 'Kanuri',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kanuri',
        'regional' => '',
      ),
      'ks' => 
      array (
        'name' => 'Kashmiri (Arabic)',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'کأشُر',
        'regional' => 'ks_IN',
      ),
      'ks-Deva' => 
      array (
        'name' => 'Kashmiri (Devaganari)',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'कॉशुर',
        'regional' => 'ks_IN',
      ),
      'ksb' => 
      array (
        'name' => 'Shambala',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kishambaa',
        'regional' => '',
      ),
      'ksf' => 
      array (
        'name' => 'Bafia',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Rikpa',
        'regional' => '',
      ),
      'ksh' => 
      array (
        'name' => 'Kölsch',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kölsch',
        'regional' => '',
      ),
      'ku' => 
      array (
        'name' => 'Kurdish',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'کوردی',
        'regional' => 'ku_TR',
      ),
      'kv' => 
      array (
        'name' => 'Komi',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Коми кыв',
        'regional' => '',
      ),
      'kw' => 
      array (
        'name' => 'Cornish',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kernewek',
        'regional' => 'kw_GB',
      ),
      'ky' => 
      array (
        'name' => 'Kyrgyz',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Кыргыз',
        'regional' => 'ky_KG',
      ),
      'la' => 
      array (
        'name' => 'Latin',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Latine',
        'regional' => '',
      ),
      'lag' => 
      array (
        'name' => 'Langi',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kɨlaangi',
        'regional' => '',
      ),
      'lah' => 
      array (
        'name' => 'Lahnda',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Lahnda',
        'regional' => '',
      ),
      'lb' => 
      array (
        'name' => 'Luxembourgish',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Lëtzebuergesch',
        'regional' => 'lb_LU',
      ),
      'lg' => 
      array (
        'name' => 'Ganda',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Luganda',
        'regional' => 'lg_UG',
      ),
      'li' => 
      array (
        'name' => 'Limburgish',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Limburgs',
        'regional' => 'li_BE',
      ),
      'ln' => 
      array (
        'name' => 'Lingala',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Lingála',
        'regional' => '',
      ),
      'lo' => 
      array (
        'name' => 'Lao',
        'script' => 'Laoo',
        'dir' => 'ltr',
        'native' => 'ລາວ',
        'regional' => 'lo_LA',
      ),
      'lt' => 
      array (
        'name' => 'Lithuanian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Lietuvių',
        'regional' => 'lt_LT',
      ),
      'lu' => 
      array (
        'name' => 'Luba-Katanga',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Tshiluba',
        'regional' => '',
      ),
      'luo' => 
      array (
        'name' => 'Luo',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Dholuo',
        'regional' => '',
      ),
      'luy' => 
      array (
        'name' => 'Oluluyia',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Luluhia',
        'regional' => '',
      ),
      'lv' => 
      array (
        'name' => 'Latvian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Latviešu',
        'regional' => 'lv_LV',
      ),
      'mai' => 
      array (
        'name' => 'Maithili',
        'script' => 'Tirh',
        'dir' => 'ltr',
        'native' => 'मैथिली',
        'regional' => 'mai_IN',
      ),
      'mas' => 
      array (
        'name' => 'Masai',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ɔl-Maa',
        'regional' => '',
      ),
      'mer' => 
      array (
        'name' => 'Kimîîru',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kĩmĩrũ',
        'regional' => '',
      ),
      'mfe' => 
      array (
        'name' => 'Morisyen',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kreol morisien',
        'regional' => '',
      ),
      'mg' => 
      array (
        'name' => 'Malagasy',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Malagasy',
        'regional' => 'mg_MG',
      ),
      'mgh' => 
      array (
        'name' => 'Makhuwa-Meetto',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Makua',
        'regional' => '',
      ),
      'mh' => 
      array (
        'name' => 'Marshallese',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kajin M̧ajeļ',
        'regional' => 'mh_MH',
      ),
      'mi' => 
      array (
        'name' => 'Māori',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Māori',
        'regional' => 'mi_NZ',
      ),
      'mk' => 
      array (
        'name' => 'Macedonian',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Македонски',
        'regional' => 'mk_MK',
      ),
      'ml' => 
      array (
        'name' => 'Malayalam',
        'script' => 'Mlym',
        'dir' => 'ltr',
        'native' => 'മലയാളം',
        'regional' => 'ml_IN',
      ),
      'mn' => 
      array (
        'name' => 'Mongolian (Cyrillic)',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Монгол',
        'regional' => 'mn_MN',
      ),
      'mn-Mong' => 
      array (
        'name' => 'Mongolian (Mongolian)',
        'script' => 'Mong',
        'dir' => 'rtl',
        'native' => 'ᠮᠣᠨᠭᠭᠣᠯ ᠬᠡᠯᠡ',
        'regional' => 'mn_MN',
      ),
      'mni' => 
      array (
        'name' => 'Manipuri',
        'script' => 'Beng',
        'dir' => 'ltr',
        'native' => 'মৈতৈ',
        'regional' => 'mni_IN',
      ),
      'mr' => 
      array (
        'name' => 'Marathi',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'मराठी',
        'regional' => 'mr_IN',
      ),
      'ms' => 
      array (
        'name' => 'Malay',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Bahasa Melayu',
        'regional' => 'ms_MY',
      ),
      'mt' => 
      array (
        'name' => 'Maltese',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Malti',
        'regional' => 'mt_MT',
      ),
      'mtr' => 
      array (
        'name' => 'Mewari',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Mewari',
        'regional' => '',
      ),
      'mua' => 
      array (
        'name' => 'Mundang',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Mundang',
        'regional' => '',
      ),
      'my' => 
      array (
        'name' => 'Burmese',
        'script' => 'Mymr',
        'dir' => 'ltr',
        'native' => 'မြန်မာဘာသာ',
        'regional' => 'my_MM',
      ),
      'na' => 
      array (
        'name' => 'Nauru',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ekakairũ Naoero',
        'regional' => '',
      ),
      'naq' => 
      array (
        'name' => 'Nama',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Khoekhoegowab',
        'regional' => '',
      ),
      'nb' => 
      array (
        'name' => 'Norwegian Bokmål',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Bokmål',
        'regional' => 'nb_NO',
      ),
      'nd' => 
      array (
        'name' => 'North Ndebele',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'IsiNdebele',
        'regional' => '',
      ),
      'nds' => 
      array (
        'name' => 'Low German',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Plattdüütsch',
        'regional' => 'nds_DE',
      ),
      'ne' => 
      array (
        'name' => 'Nepali',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'नेपाली',
        'regional' => '',
      ),
      'ng' => 
      array (
        'name' => 'Ndonga',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'OshiNdonga',
        'regional' => '',
      ),
      'nl' => 
      array (
        'name' => 'Dutch',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Nederlands',
        'regional' => 'nl_NL',
      ),
      'nmg' => 
      array (
        'name' => 'Kwasio',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ngumba',
        'regional' => '',
      ),
      'nn' => 
      array (
        'name' => 'Norwegian Nynorsk',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Nynorsk',
        'regional' => 'nn_NO',
      ),
      'nr' => 
      array (
        'name' => 'South Ndebele',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'IsiNdebele',
        'regional' => 'nr_ZA',
      ),
      'nso' => 
      array (
        'name' => 'Northern Sotho',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Sesotho sa Leboa',
        'regional' => 'nso_ZA',
      ),
      'nus' => 
      array (
        'name' => 'Nuer',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Thok Nath',
        'regional' => '',
      ),
      'nv' => 
      array (
        'name' => 'Navajo',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Diné bizaad',
        'regional' => '',
      ),
      'ny' => 
      array (
        'name' => 'Chewa',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'ChiCheŵa',
        'regional' => '',
      ),
      'nyn' => 
      array (
        'name' => 'Nyankole',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Runyankore',
        'regional' => '',
      ),
      'oc' => 
      array (
        'name' => 'Occitan',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Occitan',
        'regional' => 'oc_FR',
      ),
      'oj' => 
      array (
        'name' => 'Ojibwa',
        'script' => 'Cans',
        'dir' => 'ltr',
        'native' => 'ᐊᓂᔑᓈᐯᒧᐎᓐ',
        'regional' => '',
      ),
      'om' => 
      array (
        'name' => 'Oromo',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Oromoo',
        'regional' => 'om_ET',
      ),
      'or' => 
      array (
        'name' => 'Oriya',
        'script' => 'Orya',
        'dir' => 'ltr',
        'native' => 'ଓଡ଼ିଆ',
        'regional' => 'or_IN',
      ),
      'os' => 
      array (
        'name' => 'Ossetic',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Ирон',
        'regional' => 'os_RU',
      ),
      'pa' => 
      array (
        'name' => 'Punjabi (Gurmukhi)',
        'script' => 'Guru',
        'dir' => 'ltr',
        'native' => 'ਪੰਜਾਬੀ',
        'regional' => 'pa_IN',
      ),
      'pa-Arab' => 
      array (
        'name' => 'Punjabi (Arabic)',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'پنجاب',
        'regional' => 'pa_IN',
      ),
      'pi' => 
      array (
        'name' => 'Pahari-Potwari',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Pāli',
        'regional' => '',
      ),
      'pl' => 
      array (
        'name' => 'Polish',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Polski',
        'regional' => 'pl_PL',
      ),
      'pra' => 
      array (
        'name' => 'Prakrit',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'प्राकृत',
        'regional' => '',
      ),
      'ps' => 
      array (
        'name' => 'Pashto',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'پښتو',
        'regional' => 'ps_AF',
      ),
      'pt' => 
      array (
        'name' => 'Portuguese',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Português',
        'regional' => 'pt_PT',
      ),
      'pt-BR' => 
      array (
        'name' => 'Brazilian Portuguese',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Português do Brasil',
        'regional' => 'pt_BR',
      ),
      'qu' => 
      array (
        'name' => 'Quechua',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Runa Simi',
        'regional' => '',
      ),
      'raj' => 
      array (
        'name' => 'Rajasthani',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'राजस्थानी',
        'regional' => '',
      ),
      'ro' => 
      array (
        'name' => 'Romanian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Română',
        'regional' => 'ro_RO',
      ),
      'rof' => 
      array (
        'name' => 'Rombo',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kihorombo',
        'regional' => '',
      ),
      'rm' => 
      array (
        'name' => 'Romansh',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Rumantsch',
        'regional' => '',
      ),
      'rn' => 
      array (
        'name' => 'Rundi',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ikirundi',
        'regional' => '',
      ),
      'ru' => 
      array (
        'name' => 'Russian',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Русский',
        'regional' => 'ru_RU',
      ),
      'rw' => 
      array (
        'name' => 'Kinyarwanda',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kinyarwanda',
        'regional' => 'rw_RW',
      ),
      'rwk' => 
      array (
        'name' => 'Rwa',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kiruwa',
        'regional' => '',
      ),
      'sa' => 
      array (
        'name' => 'Sanskrit',
        'script' => 'Deva',
        'dir' => 'ltr',
        'native' => 'संस्कृतम्',
        'regional' => 'sa_IN',
      ),
      'sah' => 
      array (
        'name' => 'Yakut',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Саха тыла',
        'regional' => '',
      ),
      'saq' => 
      array (
        'name' => 'Samburu',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kisampur',
        'regional' => '',
      ),
      'sbp' => 
      array (
        'name' => 'Sileibi',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Ishisangu',
        'regional' => '',
      ),
      'sc' => 
      array (
        'name' => 'Sardinian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Sardu',
        'regional' => 'sc_IT',
      ),
      'sd' => 
      array (
        'name' => 'Sindhi',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'سنڌي',
        'regional' => 'sd_IN',
      ),
      'se' => 
      array (
        'name' => 'Northern Sami',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Davvisámegiella',
        'regional' => 'se_NO',
      ),
      'seh' => 
      array (
        'name' => 'Sena',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Sena',
        'regional' => '',
      ),
      'ses' => 
      array (
        'name' => 'Songhay',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Koyraboro senni',
        'regional' => '',
      ),
      'sg' => 
      array (
        'name' => 'Sango',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Sängö',
        'regional' => '',
      ),
      'sh' => 
      array (
        'name' => 'Serbo-Croatian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Srpskohrvatski',
        'regional' => '',
      ),
      'shi' => 
      array (
        'name' => 'Tachelhit (Latin)',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Tashelhit',
        'regional' => '',
      ),
      'shi-Tfng' => 
      array (
        'name' => 'Tachelhit (Tifinagh)',
        'script' => 'Tfng',
        'dir' => 'rtl',
        'native' => 'ⵜⴰⵎⴰⵣⵉⵖⵜ',
        'regional' => '',
      ),
      'si' => 
      array (
        'name' => 'Sinhala',
        'script' => 'Sinh',
        'dir' => 'ltr',
        'native' => 'සිංහල',
        'regional' => 'si_LK',
      ),
      'sid' => 
      array (
        'name' => 'Sidamo',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Sidaamu Afo',
        'regional' => 'sid_ET',
      ),
      'sk' => 
      array (
        'name' => 'Slovak',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Slovenčina',
        'regional' => 'sk_SK',
      ),
      'sl' => 
      array (
        'name' => 'Slovene',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Slovenščina',
        'regional' => 'sl_SI',
      ),
      'sm' => 
      array (
        'name' => 'Samoan',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Gagana fa’a Sāmoa',
        'regional' => '',
      ),
      'sn' => 
      array (
        'name' => 'Shona',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'ChiShona',
        'regional' => '',
      ),
      'so' => 
      array (
        'name' => 'Somali',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Soomaali',
        'regional' => 'so_SO',
      ),
      'sq' => 
      array (
        'name' => 'Albanian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Shqip',
        'regional' => 'sq_AL',
      ),
      'sr' => 
      array (
        'name' => 'Serbian (Cyrillic)',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Српски',
        'regional' => 'sr_RS',
      ),
      'sr-Latin' => 
      array (
        'name' => 'Serbian (Latin)',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Srpski',
        'regional' => 'sr_RS',
      ),
      'ss' => 
      array (
        'name' => 'Swati',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Siswati',
        'regional' => 'ss_ZA',
      ),
      'ssy' => 
      array (
        'name' => 'Saho',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Saho',
        'regional' => '',
      ),
      'st' => 
      array (
        'name' => 'Southern Sotho',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Sesotho',
        'regional' => 'st_ZA',
      ),
      'su' => 
      array (
        'name' => 'Sundanese',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Basa Sunda',
        'regional' => '',
      ),
      'sv' => 
      array (
        'name' => 'Swedish',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Svenska',
        'regional' => 'sv_SE',
      ),
      'sw' => 
      array (
        'name' => 'Swahili',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kiswahili',
        'regional' => 'sw_KE',
      ),
      'swc' => 
      array (
        'name' => 'Congo Swahili',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kiswahili ya Kongo',
        'regional' => '',
      ),
      'ta' => 
      array (
        'name' => 'Tamil',
        'script' => 'Taml',
        'dir' => 'ltr',
        'native' => 'தமிழ்',
        'regional' => 'ta_IN',
      ),
      'te' => 
      array (
        'name' => 'Telugu',
        'script' => 'Telu',
        'dir' => 'ltr',
        'native' => 'తెలుగు',
        'regional' => 'te_IN',
      ),
      'teo' => 
      array (
        'name' => 'Teso',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Kiteso',
        'regional' => '',
      ),
      'tg' => 
      array (
        'name' => 'Tajik (Cyrillic)',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Тоҷикӣ',
        'regional' => 'tg_TJ',
      ),
      'tg-Arab' => 
      array (
        'name' => 'Tajik (Arabic)',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'تاجیکی',
        'regional' => 'tg_TJ',
      ),
      'tg-Latin' => 
      array (
        'name' => 'Tajik (Latin)',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Tojikī',
        'regional' => 'tg_TJ',
      ),
      'th' => 
      array (
        'name' => 'Thai',
        'script' => 'Thai',
        'dir' => 'ltr',
        'native' => 'ไทย',
        'regional' => 'th_TH',
      ),
      'ti' => 
      array (
        'name' => 'Tigrinya',
        'script' => 'Ethi',
        'dir' => 'ltr',
        'native' => 'ትግርኛ',
        'regional' => 'ti_ET',
      ),
      'tig' => 
      array (
        'name' => 'Tigre',
        'script' => 'Ethi',
        'dir' => 'ltr',
        'native' => 'ትግረ',
        'regional' => 'tig_ER',
      ),
      'tk' => 
      array (
        'name' => 'Turkmen',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Түркменче',
        'regional' => 'tk_TM',
      ),
      'tl' => 
      array (
        'name' => 'Tagalog',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Tagalog',
        'regional' => 'tl_PH',
      ),
      'tn' => 
      array (
        'name' => 'Tswana',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Setswana',
        'regional' => 'tn_ZA',
      ),
      'to' => 
      array (
        'name' => 'Tongan',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Lea fakatonga',
        'regional' => '',
      ),
      'tr' => 
      array (
        'name' => 'Turkish',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Türkçe',
        'regional' => 'tr_TR',
      ),
      'trv' => 
      array (
        'name' => 'Taroko',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Seediq',
        'regional' => '',
      ),
      'ts' => 
      array (
        'name' => 'Tsonga',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Xitsonga',
        'regional' => 'ts_ZA',
      ),
      'tt' => 
      array (
        'name' => 'Tatar',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Татар теле',
        'regional' => 'tt_RU',
      ),
      'tw' => 
      array (
        'name' => 'Twi',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Twi',
        'regional' => '',
      ),
      'twq' => 
      array (
        'name' => 'Tasawaq',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Tasawaq senni',
        'regional' => '',
      ),
      'ty' => 
      array (
        'name' => 'Tahitian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Reo Māohi',
        'regional' => '',
      ),
      'tzm' => 
      array (
        'name' => 'Central Atlas Tamazight (Tifinagh)',
        'script' => 'Tfng',
        'dir' => 'rtl',
        'native' => 'ⵜⴰⵎⴰⵣⵉⵖⵜ',
        'regional' => '',
      ),
      'tzm-Latin' => 
      array (
        'name' => 'Central Atlas Tamazight (Latin)',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Tamazight',
        'regional' => '',
      ),
      'ug' => 
      array (
        'name' => 'Uyghur',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'ئۇيغۇرچە',
        'regional' => 'ug_CN',
      ),
      'uk' => 
      array (
        'name' => 'Ukrainian',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Українська',
        'regional' => 'uk_UA',
      ),
      'ur' => 
      array (
        'name' => 'Urdu',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'اردو',
        'regional' => 'ur_PK',
      ),
      'uz' => 
      array (
        'name' => 'Uzbek (Cyrillic)',
        'script' => 'Cyrl',
        'dir' => 'ltr',
        'native' => 'Ўзбек',
        'regional' => 'uz_UZ',
      ),
      'uz-Arab' => 
      array (
        'name' => 'Uzbek (Arabic)',
        'script' => 'Arab',
        'dir' => 'rtl',
        'native' => 'اۉزبېک',
        'regional' => '',
      ),
      'uz-Latin' => 
      array (
        'name' => 'Uzbek (Latin)',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Oʼzbekcha',
        'regional' => 'uz_UZ',
      ),
      'vai' => 
      array (
        'name' => 'Vai (Vai)',
        'script' => 'Vaii',
        'dir' => 'ltr',
        'native' => 'ꕙꔤ',
        'regional' => '',
      ),
      'vai-Latin' => 
      array (
        'name' => 'Vai (Latin)',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Viyamíĩ',
        'regional' => '',
      ),
      've' => 
      array (
        'name' => 'Venda',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Tshivenḓa',
        'regional' => 've_ZA',
      ),
      'vi' => 
      array (
        'name' => 'Vietnamese',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Tiếng Việt',
        'regional' => 'vi_VN',
      ),
      'vo' => 
      array (
        'name' => 'Volapük',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Volapük',
        'regional' => '',
      ),
      'wa' => 
      array (
        'name' => 'Walloon',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Walon',
        'regional' => 'wa_BE',
      ),
      'wae' => 
      array (
        'name' => 'Walser',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Walser',
        'regional' => 'wae_CH',
      ),
      'wal' => 
      array (
        'name' => 'Wolaytta',
        'script' => 'Ethi',
        'dir' => 'ltr',
        'native' => 'ወላይታቱ',
        'regional' => 'wal_ET',
      ),
      'wen' => 
      array (
        'name' => 'Sorbian',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Wendic',
        'regional' => '',
      ),
      'wo' => 
      array (
        'name' => 'Wolof',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Wolof',
        'regional' => 'wo_SN',
      ),
      'xh' => 
      array (
        'name' => 'Xhosa',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'IsiXhosa',
        'regional' => 'xh_ZA',
      ),
      'xog' => 
      array (
        'name' => 'Soga',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Olusoga',
        'regional' => '',
      ),
      'yav' => 
      array (
        'name' => 'Yangben',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Nuasue',
        'regional' => '',
      ),
      'yi' => 
      array (
        'name' => 'Yiddish',
        'script' => 'Hebr',
        'dir' => 'rtl',
        'native' => 'ייִדיש',
        'regional' => 'yi_US',
      ),
      'yo' => 
      array (
        'name' => 'Yoruba',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'Èdè Yorùbá',
        'regional' => 'yo_NG',
      ),
      'yue' => 
      array (
        'name' => 'Yue',
        'script' => 'Hant',
        'dir' => 'ltr',
        'native' => '廣州話',
        'regional' => 'yue_HK',
      ),
      'zh' => 
      array (
        'name' => 'Chinese (Simplified)',
        'script' => 'Hans',
        'dir' => 'ltr',
        'native' => '简体中文',
        'regional' => 'zh_CN',
      ),
      'zh-Hant' => 
      array (
        'name' => 'Chinese (Traditional)',
        'script' => 'Hant',
        'dir' => 'ltr',
        'native' => '繁體中文',
        'regional' => 'zh_CN',
      ),
      'zu' => 
      array (
        'name' => 'Zulu',
        'script' => 'Latn',
        'dir' => 'ltr',
        'native' => 'IsiZulu',
        'regional' => 'zu_ZA',
      ),
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.gmail.com',
        'port' => '587',
        'encryption' => 'tls',
        'username' => 'gustavolcs.271@gmail.com',
        'password' => 'BKNVIIUSFSRIKSVY',
        'timeout' => NULL,
        'auth_mode' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
    ),
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Example',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'suffix' => NULL,
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'ideasenaccion_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\resources\\views',
    ),
    'compiled' => 'C:\\Users\\Argentina\\Desktop\\IdeasEnAccion\\storage\\framework\\views',
  ),
  'flare' => 
  array (
    'key' => NULL,
    'reporting' => 
    array (
      'anonymize_ips' => true,
      'collect_git_information' => false,
      'report_queries' => true,
      'maximum_number_of_collected_queries' => 200,
      'report_query_bindings' => true,
      'report_view_data' => true,
      'grouping_type' => NULL,
    ),
    'send_logs_as_events' => true,
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'light',
    'enable_share_button' => true,
    'register_commands' => false,
    'ignored_solution_providers' => 
    array (
      0 => 'Facade\\Ignition\\SolutionProviders\\MissingPackageSolutionProvider',
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 30,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
