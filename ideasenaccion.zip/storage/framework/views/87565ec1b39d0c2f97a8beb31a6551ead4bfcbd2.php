<img src="images/img--33.jpg" alt="olas" class="w1">
<div class="d-flex flex-wrap w-100 marino flex-lg-row oh mt-3">
    <div class="col-md-6 col-lg-6 text-center mt-3" style="color: aliceblue">
        <h1 class="col-md-12 mb-4" style="font-weight: 700;letter-spacing:0.1em!important;" >Contáctenos</h1>  
        <div class="contacto">
            <p style="">¿Tienes preguntas?<br>Si tienes alguna consulta, puedes contactarnos a <a href="#">agua@iadb.org</a> o <a href="#">argentina@socialab.com</a>.</p>
        </div>
    </div>
    <div class="col-md-6">
        <form class="mr-5 mt-4 mb-5 text-right" method="POST" action="/envioMail" >
            <?php echo csrf_field(); ?>
            <div class="row mb-1 mw-100">
              <div class=" col-md-4 " >
                <input type="text" class="form-control marino" name="nombre" value="<?php echo e(old('nombre')); ?>" required autocomplete="nombre"   placeholder="Nombre">
                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group col-md-8">
                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> marino" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"  placeholder="Dirección de correro electrónico" >
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="row mb-3 mw-100">
                <div class="form-group col-md-12 mt-2">
                  <textarea class="form-control <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> radius marino" name="mensaje"  value="<?php echo e(old('mensaje')); ?>" id="" cols="30" rows="5" required autocomplete="mensaje"  placeholder="Mensaje" ></textarea>                              
                  <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
              <?php if(Session::has('mensaje')): ?>
                <div class="alert alert-success mt-1 mb-1" role="alert">
                  <?php echo e(Session::get('mensaje')); ?> 
                </div>
              <?php endif; ?>
              <button type="submit" class="btn ba mr-3" style="background-color:#eafaf5;color:#061939;border:none;font-weight: 500;">ENVIAR</button>
          </form>
    </div>
</div><?php /**PATH C:\Users\Argentina\Desktop\IdeasEnAccion\resources\views/seccion7.blade.php ENDPATH**/ ?>