<section class="text-center sp d-flex flex-column justify-content-center mx-0" style="background-color:#24939d">
    <img class="" src="images/img--31.jpg" alt="intro seccion" style="width: 48px!important;position: relative;top: -9px;margin:auto;">
    <div class="d-flex justify-content-center">
        <div class="col-md-2 d-none d-md-flex flex-column justify-content-end" style="vertical-align: bottom;display: flex;justify-content: center;">
            <img class="" src="images/img--32.jpg" alt="chico" style="opacity: 0;position: relative;right: 0;">
        </div>
        <div class="col-md-6 mt-5 mx-2">
            <h1 class="" style="line-height: 1.2em;color: aliceblue;font-weight: 650;letter-spacing:0.01em">
                <?php echo app('translator')->get('menssages.poga'); ?>
            </h1>
            <div style="height: 4px;width: 270px;background-color:#fff;display:inline-block;border-radius: 3px;position: relative;top: -5px;"></div>
            <p class="w1 mt-4 px-4 pb-5" style="color: aliceblue;font-size: x-large;font-weight: 650;">
                <?php echo app('translator')->get('menssages.p9'); ?>
            </p>
        </div>
        <div class="col-md-2 d-none d-md-flex flex-column justify-content-end" style="vertical-align: bottom;display: flex;justify-content: center;">
            <img class="" src="images/img--32.png" alt="chico" style="transform: translate(0px, 38px);">
        </div>
</section>
<div id="Contactanos" class="d-flex justify-content-center flex-column">
    <img src="images/olas.jpg" alt="olas" style="position: relative;z-index:-1;">
    
  </div><?php /**PATH C:\Users\Argentina\Desktop\IdeasEnAccion\resources\views/seccion6-4.blade.php ENDPATH**/ ?>