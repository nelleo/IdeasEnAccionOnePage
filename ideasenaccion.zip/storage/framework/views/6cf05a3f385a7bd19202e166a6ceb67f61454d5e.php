<section class="text-center sp row-fluid d-flex w1" style="background-color:#24959e;justity-content:center;margin:0%; ">
    
    <div class="offset-3 col-md-6 mt-5">
        <h1 class="" style="text-decoration: underline;line-height: 1.2em;color: aliceblue;font-weight: 650;letter-spacing:0.01em">Podrás ganar:</h1>
        <p class="w1 mt-4" style="color: aliceblue;font-size: x-large;
            font-weight: 650;">Asistencia técnica para asesorías,<br>
            estudios de prefactibilidad / factibilidad,<br>
            planes de negocios, y capacitación,<br>
            así como la implementación del proyecto piloto <br>
            enfocado a resolver el desafío formulado.
        </p>
    </div>
    <div class="offset-  col-md-2">
        <img class="w1" src="images/img--32.jpg" alt="">
    </div>
   
</section><?php /**PATH C:\Users\Argentina\Desktop\IdeasEnAccion\resources\views/seccion6-4.blade.php ENDPATH**/ ?>