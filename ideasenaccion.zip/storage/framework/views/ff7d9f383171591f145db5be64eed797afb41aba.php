
  <div id="form" class="d-flex flex-wrap w-100 marino flex-lg-row oh mt-3">
      <div class="col-md-6 col-lg-6  mt-3 text-center text-md-left" style="color: aliceblue">
          <h1 class=" mb-4 ml-md-5" style="font-weight: 700;" ><?php echo app('translator')->get('menssages.contac'); ?></h1>  
          <div class="contacto text-center text-md-left ml-sm-4 ml-md-5">
              <p style="font-size:large;">
                <?php echo app('translator')->get('menssages.p10'); ?></p>
          </div>
      </div>
      <div class="col-md-6 col-lg-6">
          <form  class="ml-4 mr-md-5  mt-4 mb-5 text-right" method="POST" action="/envioMail" >
              <?php echo csrf_field(); ?>
              <div class="row mb-1 mw-100">
                <div class=" col-md-4 pb-3" >
                  <input type="text" class="form-control marino mt-md-1" name="nombre" value="<?php echo e(old('nombre')); ?>" required autocomplete="nombre"   placeholder="<?php echo app('translator')->get('menssages.name'); ?>">
                  <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-8 mt-3 mt-md-1">
                  <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> marino" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"  placeholder="<?php echo app('translator')->get('menssages.mail'); ?>" >
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="row mb-3 mw-100">
                  <div class="form-group col-md-12 mt-2">
                    <textarea class="form-control <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> radius marino" name="mensaje"  value="<?php echo e(old('mensaje')); ?>" id="" cols="30" rows="5" required autocomplete="mensaje"  placeholder="<?php echo app('translator')->get('menssages.msj'); ?>" ></textarea>                              
                    <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>
                
                <button type="submit" class="btn ba mr-5" style="background-color:#eafaf5;color:#061939;border:none;font-weight: 500;"><?php echo app('translator')->get('menssages.send'); ?></button>
            </form>
      </div>
  </div><?php /**PATH C:\Users\Argentina\Desktop\IdeasEnAccion\resources\views/seccion8.blade.php ENDPATH**/ ?>