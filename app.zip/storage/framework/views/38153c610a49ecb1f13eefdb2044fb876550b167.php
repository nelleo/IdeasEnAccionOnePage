<section class="d-flex flex-wrap w-100 marino flex-lg-row oh">

    <div class="col-lg-6 p-0 move-right">
        <div class="d-flex flex-column flex-lg-row w-100 tlb w1 text-center text-md-left">
            <p class="p-5  w1" style="color: aliceblue;font-size:large;">
                <?php echo app('translator')->get('menssages.p1'); ?>
            </p>
        </div>
        <div>
            <img class="" src="images/img--06.jpg" alt="fin bajada">
        </div>
    </div>
    <div class="col-lg-6 w1 d-flex justify-content-center justify-content-lg-start move-left">
        <img class="float-lg-left ll" src="images/img--07.jpg" alt="ilus bajada">
    </div>

</section>
<?php /**PATH C:\Users\Argentina\Desktop\IdeasEnAccion\resources\views/seccion1.blade.php ENDPATH**/ ?>