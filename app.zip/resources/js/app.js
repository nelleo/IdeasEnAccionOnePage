require('jquery');
require('./bootstrap');
require ('jquery-visible');